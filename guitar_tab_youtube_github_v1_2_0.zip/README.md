# Guitar Tab YouTube

Extension Blender independante de Guitar Tab Studio.

## Installation
Blender > Edit > Preferences > Add-ons > Install from Disk > `guitar_tab_youtube.py`.

## GitHub et mises a jour
1. Creer le depot GitHub `lecocqleonard89-ai/Guitar-Tab-YouTube` (ou changer `Depot GitHub` dans Blender).
2. Ajouter le fichier `guitar_tab_youtube.py` a la racine du depot.
3. Dans GitHub, ouvrir **Releases > Draft a new release**.
4. Taguer la release `v1.2.0` et joindre le fichier `guitar_tab_youtube.py` en **asset** (nom exact).
5. Publier la release (non draft, non prerelease).
6. Dans Blender > N > Guitar Tab YT > Verifier les mises a jour.
7. Pour une nouvelle version, augmenter `bl_info['version']`, creer un tag plus recent (`v1.2.1` etc.) et joindre le meme nom de fichier.

Le bouton Installer effectue une sauvegarde `.backup` et demande un redemarrage de Blender. Il telecharge du code Python depuis les releases du depot configure : ne choisir qu'un depot de confiance.

La release initiale v1.2.0 est a publier manuellement. Tant qu'elle n'est pas publiee, le bouton ne peut pas trouver de mise a jour.
