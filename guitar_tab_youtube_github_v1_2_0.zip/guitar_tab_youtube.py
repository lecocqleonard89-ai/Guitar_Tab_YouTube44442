bl_info = {
    'name': 'Guitar Tab YouTube',
    'author': 'Guitar Tab YouTube Project',
    'version': (1, 2, 0),
    'blender': (4, 2, 0),
    'location': 'View3D > Sidebar > Guitar Tab YT',
    'description': 'Create scrolling animated guitar tablatures from TuxGuitar MusicXML',
    'category': 'Animation',
}

import bpy
import os
import math
import zipfile
import urllib.request
import json
import ast
import tempfile
import shutil
import re
import xml.etree.ElementTree as ET
from bpy.props import StringProperty, EnumProperty, IntProperty, FloatProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper
from mathutils import Vector

COLLECTION_NAME = 'GTYT_GENERATED'
# GitHub repository for this independent YouTube tablature add-on.
# Create this repository and publish releases with the asset name below.
DEFAULT_REPOSITORY = 'lecocqleonard89-ai/Guitar-Tab-YouTube'
UPDATE_ASSET = 'guitar_tab_youtube.py'
MAX_UPDATE_BYTES = 2_000_000

TUNINGS = {
    'E': ('E Standard', ['E4','B3','G3','D3','A2','E2']),
    'EB': ('Eb Standard', ['Eb4','Bb3','Gb3','Db3','Ab2','Eb2']),
    'D': ('D Standard', ['D4','A3','F3','C3','G2','D2']),
    'DROP_D': ('Drop D', ['E4','B3','G3','D3','A2','D2']),
    'DROP_C': ('Drop C', ['D4','A3','F3','C3','G2','C2']),
    'DADGAD': ('DADGAD', ['D4','A3','G3','D3','A2','D2']),
}

def child(el, name):
    if el is None:
        return None
    return next((x for x in el if x.tag.rsplit('}', 1)[-1] == name), None)

def children(el, name):
    if el is None:
        return []
    return [x for x in el if x.tag.rsplit('}', 1)[-1] == name]

def ctext(el, name, default=None):
    node = child(el, name)
    return node.text.strip() if node is not None and node.text else default

def get_musicxml_root(path):
    if path.lower().endswith('.mxl'):
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.lower().endswith(('.xml', '.musicxml')) and not n.startswith('META-INF/')]
            if not names:
                raise ValueError('Fichier MXL sans MusicXML.')
            return ET.fromstring(z.read(names[0]))
    return ET.parse(path).getroot()

def parse_musicxml(path, fps, fallback_bpm):
    root = get_musicxml_root(path)
    parts = children(root, 'part')
    if not parts:
        raise ValueError('Aucune partie MusicXML trouvee.')
    # Prefer the first part containing explicit string/fret technical notation.
    def score_part(p):
        return sum(1 for n in p.iter() if n.tag.rsplit('}', 1)[-1] == 'fret')
    part = max(parts, key=score_part)
    if score_part(part) == 0:
        raise ValueError('Aucun numero de corde/case detecte. Exporter la TAB en MusicXML depuis TuxGuitar.')
    divisions = 1
    bpm = float(fallback_bpm)
    elapsed = 0.0
    events = []
    slide_starts = {}
    last_start = 0.0
    measures = children(part, 'measure')
    for measure in measures:
        cursor = 0.0
        max_cursor = 0.0
        for item in measure:
            tag = item.tag.rsplit('}', 1)[-1]
            if tag == 'attributes':
                div = ctext(item, 'divisions')
                if div:
                    divisions = max(1, int(div))
            elif tag == 'direction':
                sound = child(item, 'sound')
                if sound is not None and sound.get('tempo'):
                    bpm = max(1.0, float(sound.get('tempo')))
                else:
                    dt = child(item, 'direction-type')
                    metro = child(dt, 'metronome')
                    per = ctext(metro, 'per-minute')
                    if per:
                        bpm = max(1.0, float(per))
            elif tag == 'sound' and item.get('tempo'):
                bpm = max(1.0, float(item.get('tempo')))
            elif tag == 'backup':
                cursor -= float(ctext(item, 'duration', '0')) / divisions * 60.0 / bpm
                cursor = max(0, cursor)
            elif tag == 'forward':
                cursor += float(ctext(item, 'duration', '0')) / divisions * 60.0 / bpm
                max_cursor = max(max_cursor, cursor)
            elif tag == 'note':
                chord = child(item, 'chord') is not None
                dur = float(ctext(item, 'duration', '0')) / divisions * 60.0 / bpm
                start = last_start if chord else cursor
                if not chord:
                    last_start = start
                if child(item, 'rest') is None:
                    notation = child(item, 'notations')
                    tech = child(notation, 'technical')
                    s = ctext(tech, 'string')
                    f = ctext(tech, 'fret')
                    if s is not None and f is not None:
                        string, fret = int(s), int(f)
                        if 1 <= string <= 6 and 0 <= fret <= 30:
                            effects = []
                            # MusicXML: slides are paired start/stop elements.
                            # TuxGuitar may put the slide in <notations> or <technical>.
                            slide_nodes = children(notation, 'slide') + children(tech, 'slide')
                            for sl in slide_nodes:
                                kind = sl.get('type', '').lower()
                                key = (string, sl.get('number', '1'))
                                if kind == 'start':
                                    slide_starts[key] = (elapsed + start, fret)
                                elif kind == 'stop':
                                    previous = slide_starts.pop(key, None)
                                    if previous:
                                        effects.append(('slide_from', previous[0], previous[1]))
                                elif kind == '':
                                    effects.append(('slide_hint',))
                            bend = child(tech, 'bend')
                            if bend is not None:
                                amount = ctext(bend, 'bend-alter')
                                effects.append(('bend', float(amount) if amount else 1.0))
                            if child(tech, 'hammer-on') is not None: effects.append(('text', 'H'))
                            if child(tech, 'pull-off') is not None: effects.append(('text', 'P'))
                            if child(notation, 'ornaments') is not None and child(child(notation, 'ornaments'), 'wavy-line') is not None:
                                effects.append(('text', '~'))
                            events.append((elapsed + start, string, fret, effects))
                if not chord:
                    cursor += dur
                    max_cursor = max(max_cursor, cursor)
        elapsed += max_cursor
    events.sort(key=lambda e: e[0])
    if not events:
        raise ValueError('Aucune note avec corde et case exploitable.')
    return events, elapsed

def mat(name, color, emission=0):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    if bsdf:
        bsdf.inputs['Base Color'].default_value = (*color, 1)
        bsdf.inputs['Roughness'].default_value = .8
        bsdf.inputs['Emission Color'].default_value = (*color, 1)
        bsdf.inputs['Emission Strength'].default_value = emission
    return m

def curve_line(name, points, radius, material, col, parent=None):
    cu = bpy.data.curves.new(name, 'CURVE')
    cu.dimensions = '3D'
    cu.bevel_depth = radius
    cu.bevel_resolution = 3
    sp = cu.splines.new('POLY')
    sp.points.add(len(points)-1)
    for p, co in zip(sp.points, points):
        p.co = (*co, 1)
    obj = bpy.data.objects.new(name, cu)
    col.objects.link(obj)
    cu.materials.append(material)
    if parent: obj.parent = parent
    return obj

def text_obj(name, body, x, y, size, material, col, parent=None):
    cu = bpy.data.curves.new(name, 'FONT')
    cu.body = body
    cu.align_x = 'CENTER'
    cu.align_y = 'CENTER'
    cu.size = size
    cu.extrude = 0
    obj = bpy.data.objects.new(name, cu)
    col.objects.link(obj)
    obj.location = (x,y,0.015)
    cu.materials.append(material)
    if parent: obj.parent = parent
    return obj

def draw_bend_arrow(name, x, y, amount, material, col, parent):
    """Rounded upward arrow, ending in a clear arrowhead above the note."""
    rise = .48 + min(1.0, abs(amount)) * .22
    pts = []
    for i in range(21):
        t = i / 20.0
        pts.append((x + .13 + .34*t, y + .15 + rise*(t*t*(3-2*t)), .035))
    curve_line(name + ' | Curve', pts, .018, material, col, parent)
    tip = pts[-1]
    curve_line(name + ' | Arrowhead', [
        (tip[0]-.14,tip[1]-.075,.035), tip,
        (tip[0]+.005,tip[1]-.16,.035)
    ], .019, material, col, parent)
    if abs(amount) >= .95:
        text_obj(name + ' | Full', 'full' if amount < 1.9 else '1 1/2', x+.66, y+rise+.16, .16, material, col, parent)
    elif abs(amount) >= .45:
        text_obj(name + ' | Half', '1/2', x+.64, y+rise+.16, .16, material, col, parent)

def draw_slide(name, x0, x1, y, upward, material, col, parent):
    """Diagonal connecting stroke between two note numbers."""
    if x1 <= x0 + .12:
        return
    a = x0 + min(.26, (x1-x0)*.25)
    b = x1 - min(.26, (x1-x0)*.25)
    if b <= a: return
    dy = .22 if upward else -.22
    curve_line(name, [(a,y-dy,.035),(b,y+dy,.035)], .017, material, col, parent)

def build(context, settings, filepath):
    fps = context.scene.render.fps
    events, duration = parse_musicxml(filepath, fps, settings.fallback_bpm)
    old = bpy.data.collections.get(COLLECTION_NAME)
    if old:
        for obj in list(old.objects): bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.collections.remove(old)
    col = bpy.data.collections.new(COLLECTION_NAME)
    context.scene.collection.children.link(col)
    dark = mat('GTYT | Background', (.012,.015,.022))
    lines = mat('GTYT | Strings', (.21,.24,.29))
    white = mat('GTYT | Numbers', (.82,.87,.94), .12)
    blue = mat('GTYT | Electric Blue', (.005,.28,1.0), 8.0)
    muted = mat('GTYT | Labels', (.40,.46,.56))
    # Ortho camera: X horizontal, Y vertical. Scene geometry is on XY plane.
    bpy.ops.object.camera_add(location=(0,0,25))
    camera = context.object
    camera.name = 'GTYT | Camera'
    for c in list(camera.users_collection): c.objects.unlink(camera)
    col.objects.link(camera)
    camera.data.type = 'ORTHO'
    camera.data.ortho_scale = 19.2
    context.scene.camera = camera
    context.scene.render.resolution_x = 1920
    context.scene.render.resolution_y = 1080
    context.scene.render.resolution_percentage = 100
    context.scene.render.fps = 60
    context.scene.world.color = (.012,.015,.022)
    # Large flat background (visible to camera and in renders).
    bpy.ops.mesh.primitive_plane_add(size=2, location=(0,0,-.25))
    bg = context.object
    bg.name = 'GTYT | Dark Background'
    bg.scale = (12,7,1)
    for c in list(bg.users_collection): c.objects.unlink(bg)
    col.objects.link(bg)
    bg.data.materials.append(dark)
    root = bpy.data.objects.new('GTYT | Scrolling Notes', None)
    col.objects.link(root)
    spacing = 0.80
    ys = [2.0-i*spacing for i in range(6)]
    width = 9.0
    for i, y in enumerate(ys):
        curve_line('GTYT | String %d' % (i+1), [(-width,y,0),(width,y,0)], .012, lines, col)
    tuning = [s.strip() for s in settings.custom_tuning.split(',')] if settings.tuning == 'CUSTOM' else TUNINGS[settings.tuning][1]
    if len(tuning) != 6: raise ValueError('Accordage personnalise : 6 notes separees par des virgules, de aigu a grave.')
    for i, y in enumerate(ys):
        text_obj('GTYT | Tuning %d' % (i+1), tuning[i], -8.75, y, .28, muted, col)
    curve_line('GTYT | Playhead', [(0,2.45,.06),(0,-2.45,.06)], .025, blue, col)
    # Notes move in one parent; world position x = time*speed - currentTime*speed.
    speed = settings.scroll_speed
    # The original note numbers remain unchanged; FX are separate objects.
    note_positions = {(round(t, 6), string, fret): t*speed for t, string, fret, fx in events}
    for idx, (seconds, string, fret, effects) in enumerate(events):
        x = seconds*speed
        y = ys[string-1]
        text_obj('GTYT | Note %05d' % idx, str(fret), x, y, .43, white, col, root)
        for fx in effects:
            if fx[0] == 'bend':
                draw_bend_arrow('GTYT | Bend %05d' % idx, x, y, fx[1], blue, col, root)
            elif fx[0] == 'slide_from':
                _, from_time, from_fret = fx
                draw_slide('GTYT | Slide %05d' % idx, from_time*speed, x, y, fret >= from_fret, blue, col, root)
            elif fx[0] == 'slide_hint':
                # Some exporters omit start/stop: draw a short slash after the note.
                draw_slide('GTYT | Slide hint %05d' % idx, x, x+.95, y, True, blue, col, root)
            elif fx[0] == 'text':
                text_obj('GTYT | FX %05d' % idx, fx[1], x+.34, y+.29, .18, blue, col, root)
    first = 1
    last = max(2, math.ceil((duration+settings.tail_seconds)*60)+1)
    root.location.x = 0
    root.keyframe_insert(data_path='location', frame=first, index=0)
    root.location.x = -(last-first)/60*speed
    root.keyframe_insert(data_path='location', frame=last, index=0)
    if root.animation_data and root.animation_data.action:
        action = root.animation_data.action
        try:
            for fc in action.fcurves:
                for k in fc.keyframe_points: k.interpolation = 'LINEAR'
        except AttributeError:
            # Blender 4.4+ layered actions may require channelbag traversal.
            for layer in action.layers:
                for strip in layer.strips:
                    for bag in strip.channelbags:
                        for fc in bag.fcurves:
                            for k in fc.keyframe_points: k.interpolation = 'LINEAR'
    scene = context.scene
    scene.frame_start = first
    scene.frame_end = last
    scene.frame_set(first)
    scene.render.image_settings.file_format = 'PNG'
    scene.render.film_transparent = False
    return len(events), duration

class GTYT_Settings(bpy.types.PropertyGroup):
    tuning: EnumProperty(name='Accordage', items=[(key, value[0], '') for key,value in TUNINGS.items()] + [('CUSTOM','Personnalise','')], default='E')
    custom_tuning: StringProperty(name='Notes aigu → grave', default='E4,B3,G3,D3,A2,E2')
    xml_path: StringProperty(name='MusicXML', subtype='FILE_PATH', default='')
    fallback_bpm: FloatProperty(name='BPM si absent', default=120, min=20, max=400)
    scroll_speed: FloatProperty(name='Vitesse de defilement', default=3.5, min=.5, max=12)
    tail_seconds: FloatProperty(name='Fin (secondes)', default=2, min=0, max=20)
    github_repo: StringProperty(name='Depot GitHub', default=DEFAULT_REPOSITORY, description='owner/repository GitHub')
    update_status: StringProperty(name='Mises a jour', default='Pas encore verifie')
    update_tag: StringProperty(default='')
    update_url: StringProperty(default='')

class GTYT_OT_pick(bpy.types.Operator, ImportHelper):
    bl_idname = 'gtyt.pick_xml'
    bl_label = 'Choisir une tablature'
    bl_description = 'Importer un fichier MusicXML exporte depuis TuxGuitar'
    filename_ext = '.musicxml'
    filter_glob: StringProperty(default='*.musicxml;*.xml;*.mxl', options={'HIDDEN'})
    def execute(self, context):
        context.scene.gtyt_settings.xml_path = self.filepath
        self.report({'INFO'}, 'Tablature selectionnee : ' + os.path.basename(self.filepath))
        return {'FINISHED'}

class GTYT_OT_generate(bpy.types.Operator):
    bl_idname = 'gtyt.generate'
    bl_label = 'Generer la tablature'
    bl_description = 'Creer la scene et animer la tablature depuis le MusicXML'
    bl_options = {'REGISTER','UNDO'}
    def execute(self, context):
        st = context.scene.gtyt_settings
        path = bpy.path.abspath(st.xml_path)
        if not os.path.isfile(path):
            self.report({'ERROR'}, 'Choisis un fichier MusicXML valide.')
            return {'CANCELLED'}
        try:
            count, duration = build(context, st, path)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, '%d notes creees, duree %.1f s' % (count, duration))
        return {'FINISHED'}


def gtyt_version(tag):
    match = re.fullmatch(r'v?(\d+)\.(\d+)\.(\d+)', tag.strip())
    if not match:
        raise ValueError('Version GitHub attendue : v1.2.1')
    return tuple(map(int, match.groups()))


def gtyt_repo(settings):
    repo = settings.github_repo.strip()
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo):
        raise ValueError('Depot GitHub invalide : owner/repository')
    return repo


class GTYT_OT_check_updates(bpy.types.Operator):
    bl_idname = 'gtyt.check_updates'
    bl_label = 'Verifier les mises a jour'
    bl_description = 'Verifier la derniere release GitHub publiee'

    def execute(self, context):
        st = context.scene.gtyt_settings
        st.update_tag = ''
        st.update_url = ''
        try:
            repo = gtyt_repo(st)
            api = 'https://api.github.com/repos/' + repo + '/releases/latest'
            req = urllib.request.Request(api, headers={'User-Agent':'GuitarTabYouTube-Updater/1.2', 'Accept':'application/vnd.github+json'})
            with urllib.request.urlopen(req, timeout=12) as response:
                release = json.load(response)
            tag = release['tag_name']
            version = gtyt_version(tag)
            if release.get('draft') or release.get('prerelease'):
                raise ValueError('Release non stable')
            if version <= tuple(bl_info['version']):
                st.update_status = 'A jour : v' + '.'.join(map(str, bl_info['version']))
                self.report({'INFO'}, st.update_status)
                return {'FINISHED'}
            assets = [a for a in release.get('assets', []) if a.get('name') == UPDATE_ASSET]
            if len(assets) != 1:
                raise ValueError('Release sans fichier ' + UPDATE_ASSET)
            asset = assets[0]
            url = asset.get('browser_download_url', '')
            if not url.startswith('https://github.com/' + repo + '/releases/download/'):
                raise ValueError('Adresse de telechargement inattendue')
            if not 0 < int(asset.get('size', 0)) <= MAX_UPDATE_BYTES:
                raise ValueError('Taille du fichier invalide')
            st.update_tag = tag
            st.update_url = url
            st.update_status = 'Nouvelle version : ' + tag
            self.report({'INFO'}, st.update_status)
            return {'FINISHED'}
        except Exception as exc:
            st.update_status = 'Verification impossible : ' + str(exc)[:110]
            self.report({'WARNING'}, st.update_status)
            return {'CANCELLED'}


class GTYT_OT_install_update(bpy.types.Operator):
    bl_idname = 'gtyt.install_update'
    bl_label = 'Installer la mise a jour'
    bl_description = 'Sauvegarder le fichier actuel et installer la release, puis redemarrer Blender'

    @classmethod
    def poll(cls, context):
        st = getattr(context.scene, 'gtyt_settings', None)
        return bool(st and st.update_tag and st.update_url)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        st = context.scene.gtyt_settings
        temp_path = None
        try:
            repo = gtyt_repo(st)
            target = os.path.abspath(__file__)
            if not os.path.isfile(target) or not target.endswith('.py'):
                raise ValueError('Installer le module .py dans les Add-ons pour utiliser la mise a jour')
            if not st.update_url.startswith('https://github.com/' + repo + '/releases/download/'):
                raise ValueError('URL de release invalide')
            version = gtyt_version(st.update_tag)
            req = urllib.request.Request(st.update_url, headers={'User-Agent':'GuitarTabYouTube-Updater/1.2'})
            with urllib.request.urlopen(req, timeout=20) as response:
                data = response.read(MAX_UPDATE_BYTES + 1)
            if not data or len(data) > MAX_UPDATE_BYTES:
                raise ValueError('Fichier telecharge invalide')
            tree = ast.parse(data.decode('utf-8-sig'), filename=UPDATE_ASSET)
            node = next((n.value for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'bl_info' for t in n.targets)), None)
            if node is None:
                raise ValueError('Metadonnees bl_info absentes')
            info = ast.literal_eval(node)
            if info.get('name') != bl_info['name'] or tuple(info.get('version', ())) != version:
                raise ValueError('Nom ou version du module incorrects')
            if version <= tuple(bl_info['version']):
                raise ValueError('Version deja installee')
            folder = os.path.dirname(target)
            fd, temp_path = tempfile.mkstemp(prefix='.gtyt_update_', suffix='.py', dir=folder)
            with os.fdopen(fd, 'wb') as out:
                out.write(data)
            shutil.copy2(target, target + '.backup')
            os.replace(temp_path, target)
            temp_path = None
            st.update_status = 'Installee : ' + st.update_tag + ' - REDEMARRER BLENDER'
            st.update_tag = ''
            st.update_url = ''
            self.report({'INFO'}, 'Mise a jour installee. Redemarrer Blender.')
            return {'FINISHED'}
        except Exception as exc:
            st.update_status = 'Installation impossible : ' + str(exc)[:110]
            self.report({'ERROR'}, st.update_status)
            return {'CANCELLED'}
        finally:
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)

class GTYT_PT_panel(bpy.types.Panel):
    bl_label = 'Guitar Tab YouTube'
    bl_idname = 'GTYT_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Guitar Tab YT'
    def draw(self, context):
        layout = self.layout
        st = context.scene.gtyt_settings
        layout.label(text='TABLATURE YOUTUBE', icon='SEQ_STRIP_DUPLICATE')
        layout.prop(st, 'tuning')
        if st.tuning == 'CUSTOM': layout.prop(st, 'custom_tuning')
        layout.separator()
        layout.operator('gtyt.pick_xml', icon='FILE_FOLDER')
        layout.prop(st, 'xml_path', text='Fichier')
        layout.prop(st, 'fallback_bpm')
        layout.prop(st, 'scroll_speed')
        layout.prop(st, 'tail_seconds')
        layout.separator()
        layout.operator('gtyt.generate', icon='PLAY')
        layout.label(text='MusicXML / MXL depuis TuxGuitar')
        layout.label(text='1920x1080 | 60 FPS')
        layout.separator()
        box = layout.box()
        box.label(text='MISES A JOUR GITHUB', icon='FILE_REFRESH')
        box.prop(st, 'github_repo')
        box.operator('gtyt.check_updates', icon='FILE_REFRESH')
        if st.update_tag and st.update_url:
            box.operator('gtyt.install_update', icon='IMPORT')
        box.label(text=st.update_status[:75])

CLASSES = (GTYT_Settings, GTYT_OT_pick, GTYT_OT_generate, GTYT_OT_check_updates, GTYT_OT_install_update, GTYT_PT_panel)
def register():
    for cls in CLASSES: bpy.utils.register_class(cls)
    bpy.types.Scene.gtyt_settings = bpy.props.PointerProperty(type=GTYT_Settings)
def unregister():
    del bpy.types.Scene.gtyt_settings
    for cls in reversed(CLASSES): bpy.utils.unregister_class(cls)
if __name__ == '__main__': register()
